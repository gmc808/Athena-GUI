export default function App() {
  return (
    <div>
      <h1>Hello, Athena GUI!</h1>
    </div>
  );
}