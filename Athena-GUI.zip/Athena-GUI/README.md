# Athena GUI Demo

This is a minimal React setup configured with Vite and Tailwind CSS for demo purposes.

## Setup

```bash
npm install
npm run dev
```